function widget:GetInfo()
  return {
    name      = "Propeller FX - PL",
    desc      = "Draws motion-blurred propellers on aircraft, up to 4 per unit",
    author    = "Zpock, modified by Pressure Line",
    date      = "6 December, 2008",
    license   = "free 4 all",
    layer     = 10000,
    enabled   = true  --  loaded by default?
  }
end

function widget:DrawWorld()

	local units = Spring.GetAllUnits()

	for key, value in pairs(units) do
		local type = Spring.GetUnitDefID(value)
		
		if(type ~= nil) then
			if (UnitDefs[type]["customParams"]["hasprops"] ~= nil) then
				if(Spring.GetCOBUnitVar(value, 0) == 1) then

----------------------------------------Propeller #1------------------------------------------
					if (UnitDefs[type]["customParams"]["prop1pos"] ~= nil) then
					local prop1pos = UnitDefs[type]["customParams"]["prop1pos"]
	
					local pieces = Spring.GetUnitPieceList(value)

					for key1, value1 in pairs(pieces) do
						if(string.sub(value1,1,-1) == prop1pos) then
							gl.DepthTest(true)
							gl.PushMatrix() 
					 		gl.UnitMultMatrix(value)
							gl.UnitPieceMultMatrix(value,key1)
							gl.Texture(UnitDefs[type]["customParams"]["prop1tex"])

							local size1 = UnitDefs[type]["customParams"]["prop1size"]

							gl.BeginEnd(GL.QUADS, function()
  								gl.TexCoord(0,0)
								gl.Vertex(size1,size1,0)
  								gl.TexCoord(1,0)
								gl.Vertex(-size1,size1,0)
  								gl.TexCoord(1,1)
								gl.Vertex(-size1,-size1,0)
    								gl.TexCoord(0,1)
								gl.Vertex(size1,-size1,0)
 							end)
						gl.PopMatrix()
						end

					end
					end

----------------------------------------Propeller #2------------------------------------------
					if (UnitDefs[type]["customParams"]["prop2pos"] ~= nil) then
					local prop2pos = UnitDefs[type]["customParams"]["prop2pos"]
	
					local pieces = Spring.GetUnitPieceList(value)

					for key1, value1 in pairs(pieces) do
						if(string.sub(value1,1,-1) == prop2pos) then
							gl.DepthTest(true)
							gl.PushMatrix() 
					 		gl.UnitMultMatrix(value)
							gl.UnitPieceMultMatrix(value,key1)
							gl.Texture(UnitDefs[type]["customParams"]["prop2tex"])
							local size2 = UnitDefs[type]["customParams"]["prop2size"]
							gl.BeginEnd(GL.QUADS, function()
  								gl.TexCoord(0,0)
								gl.Vertex(size2,size2,0)
	  							gl.TexCoord(1,0)
								gl.Vertex(-size2,size2,0)
  								gl.TexCoord(1,1)
								gl.Vertex(-size2,-size2,0)
    								gl.TexCoord(0,1)
								gl.Vertex(size2,-size2,0)
 							end)
						gl.PopMatrix()
						end
					end
					end

----------------------------------------Propeller #3------------------------------------------
					if (UnitDefs[type]["customParams"]["prop3pos"] ~= nil) then
					local prop1pos = UnitDefs[type]["customParams"]["prop3pos"]
	
					local pieces = Spring.GetUnitPieceList(value)

					for key1, value1 in pairs(pieces) do
						if(string.sub(value1,1,-1) == prop1pos) then
							gl.DepthTest(true)
							gl.PushMatrix() 
					 		gl.UnitMultMatrix(value)
							gl.UnitPieceMultMatrix(value,key1)
							gl.Texture(UnitDefs[type]["customParams"]["prop3tex"])

							local size1 = UnitDefs[type]["customParams"]["prop3size"]

							gl.BeginEnd(GL.QUADS, function()
  								gl.TexCoord(0,0)
								gl.Vertex(size3,size3,0)
  								gl.TexCoord(1,0)
								gl.Vertex(-size3,size3,0)
  								gl.TexCoord(1,1)
								gl.Vertex(-size3,-size3,0)
    								gl.TexCoord(0,1)
								gl.Vertex(size3,-size3,0)
 							end)
						gl.PopMatrix()
						end

					end
					end

----------------------------------------Propeller #4------------------------------------------
					if (UnitDefs[type]["customParams"]["prop4pos"] ~= nil) then
					local prop1pos = UnitDefs[type]["customParams"]["prop4pos"]
	
					local pieces = Spring.GetUnitPieceList(value)

					for key1, value1 in pairs(pieces) do
						if(string.sub(value1,1,-1) == prop4pos) then
							gl.DepthTest(true)
							gl.PushMatrix() 
					 		gl.UnitMultMatrix(value)
							gl.UnitPieceMultMatrix(value,key1)
							gl.Texture(UnitDefs[type]["customParams"]["prop4tex"])

							local size1 = UnitDefs[type]["customParams"]["prop4size"]

							gl.BeginEnd(GL.QUADS, function()
  								gl.TexCoord(0,0)
								gl.Vertex(size4,size4,0)
  								gl.TexCoord(1,0)
								gl.Vertex(-size4,size4,0)
  								gl.TexCoord(1,1)
								gl.Vertex(-size4,-size4,0)
    								gl.TexCoord(0,1)
								gl.Vertex(size4,-size4,0)
 							end)
						gl.PopMatrix()
						end

					end
					end

				end
			end
		end
	end
	gl.ResetState()
end